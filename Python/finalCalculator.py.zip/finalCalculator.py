# =====================================================
# FINAL PCEP CALCULATOR – CLEAN, PROFESSIONAL & FUN
# =====================================================
# Features: Add, Subtract, Multiply, Divide, Power, Square Root, Floor
# Uses: import math, try-except, functions, loops, nice formatting

import math                                      # Needed for sqrt, pow, floor

print("Welcome to the FINAL CALCULATOR")
print("All results are accurate and safe!\n")

def get_number(prompt):
    """Safely get a valid number from user"""
    while True:
        try:
            return float(input(prompt))
        except ValueError:
            print("Error! Please enter a real number.")

# === MATH FUNCTIONS ===
def add(x, y):          return x + y
def subtract(x, y):     return x - y
def multiply(x, y):     return x * y

def divide(x, y):
    if y == 0:
        return "Error: Cannot divide by zero!"
    return x / y

def power(base, exp):
    return math.pow(base, exp)          # or: base ** exp

def square_root(x):
    if x < 0:
        return "Error: Cannot take square root of negative number"
    return math.sqrt(x)

def floor_value(x):
    return math.floor(x)                # Rounds DOWN always

# === MAIN MENU LOOP ===
while True:
    print("=" * 45)
    print("           FINAL CALCULATOR")
    print("=" * 45)
    print("1. Add (+)            5. Power (x^y)")
    print("2. Subtract (−)       6. Square Root (√x)")
    print("3. Multiply (×)       7. Floor (round down)")
    print("4. Divide (÷)         8. Quit")
    print()

    choice = input("Choose (1–8): ").strip()

    if choice == "8":
        print("\nThank you for using Final Calculator!")
        print("See you next time!")
        break

    elif choice in ["1", "2", "3", "4"]:
        a = get_number("Enter first number : ")
        b = get_number("Enter second number: ")
        
        if   choice == "1": result = add(a, b);         op = "+"
        elif choice == "2": result = subtract(a, b);    op = "−"
        elif choice == "3": result = multiply(a, b);    op = "×"
        elif choice == "4": result = divide(a, b);      op = "÷"

        print(f"\nResult: {a} {op} {b} = {result}\n")

    elif choice == "5":
        base = get_number("Enter base     : ")
        exp  = get_number("Enter exponent : ")
        print(f"\nResult: {base} ^ {exp} = {power(base, exp)}\n")

    elif choice == "6":
        num = get_number("Enter number   : ")
        print(f"\nResult: √{num} = {square_root(num)}\n")

    elif choice == "7":
        num = get_number("Enter number   : ")
        print(f"\nResult: floor({num}) = {floor_value(num)}\n")

    else:
        print("Invalid option! Please choose 1–8.\n")